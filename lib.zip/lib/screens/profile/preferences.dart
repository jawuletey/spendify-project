import 'package:flutter/material.dart';

class PaymentPreferences extends StatelessWidget {
  const PaymentPreferences({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
