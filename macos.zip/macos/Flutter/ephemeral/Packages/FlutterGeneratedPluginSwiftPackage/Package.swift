// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.
//
//  Generated file. Do not edit.
//

import PackageDescription

let package = Package(
    name: "FlutterGeneratedPluginSwiftPackage",
    platforms: [
        .macOS("10.14")
    ],
    products: [
        .library(name: "FlutterGeneratedPluginSwiftPackage", type: .static, targets: ["FlutterGeneratedPluginSwiftPackage"])
    ],
    dependencies: [
        .package(name: "cloud_firestore", path: "/Users/owner/.pub-cache/hosted/pub.dev/cloud_firestore-5.6.11/macos/cloud_firestore"),
        .package(name: "firebase_auth", path: "/Users/owner/.pub-cache/hosted/pub.dev/firebase_auth-5.6.2/macos/firebase_auth"),
        .package(name: "firebase_core", path: "/Users/owner/.pub-cache/hosted/pub.dev/firebase_core-3.15.1/macos/firebase_core"),
        .package(name: "firebase_storage", path: "/Users/owner/.pub-cache/hosted/pub.dev/firebase_storage-12.4.9/macos/firebase_storage"),
        .package(name: "local_auth_darwin", path: "/Users/owner/.pub-cache/hosted/pub.dev/local_auth_darwin-1.5.0/darwin/local_auth_darwin"),
        .package(name: "path_provider_foundation", path: "/Users/owner/.pub-cache/hosted/pub.dev/path_provider_foundation-2.4.1/darwin/path_provider_foundation"),
        .package(name: "shared_preferences_foundation", path: "/Users/owner/.pub-cache/hosted/pub.dev/shared_preferences_foundation-2.5.4/darwin/shared_preferences_foundation"),
        .package(name: "url_launcher_macos", path: "/Users/owner/.pub-cache/hosted/pub.dev/url_launcher_macos-3.2.2/macos/url_launcher_macos"),
        .package(name: "webview_flutter_wkwebview", path: "/Users/owner/.pub-cache/hosted/pub.dev/webview_flutter_wkwebview-3.22.0/darwin/webview_flutter_wkwebview")
    ],
    targets: [
        .target(
            name: "FlutterGeneratedPluginSwiftPackage",
            dependencies: [
                .product(name: "cloud-firestore", package: "cloud_firestore"),
                .product(name: "firebase-auth", package: "firebase_auth"),
                .product(name: "firebase-core", package: "firebase_core"),
                .product(name: "firebase-storage", package: "firebase_storage"),
                .product(name: "local-auth-darwin", package: "local_auth_darwin"),
                .product(name: "path-provider-foundation", package: "path_provider_foundation"),
                .product(name: "shared-preferences-foundation", package: "shared_preferences_foundation"),
                .product(name: "url-launcher-macos", package: "url_launcher_macos"),
                .product(name: "webview-flutter-wkwebview", package: "webview_flutter_wkwebview")
            ]
        )
    ]
)
